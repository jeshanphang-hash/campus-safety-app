import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Auth } from './components/Auth';
import { Home } from './components/Home';
import { Announcements } from './components/Announcements';
import { Report } from './components/Report';
import { DisasterSensor } from './components/DisasterSensor';
import { FirstAid } from './components/FirstAid';
import { Settings } from './components/Settings';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setActiveTab('home'); // Reset to home tab when logging out
  };

  const renderActiveScreen = () => {
    switch (activeTab) {
      case 'home':
        return <Home onNavigate={setActiveTab} />;
      case 'announcements':
        return <Announcements />;
      case 'report':
        return <Report />;
      case 'disaster':
        return <DisasterSensor />;
      case 'firstaid':
        return <FirstAid />;
      case 'settings':
        return <Settings onLogout={handleLogout} />;
      default:
        return <Home onNavigate={setActiveTab} />;
    }
  };

  // Show auth page if not authenticated
  if (!isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Main Content */}
      <main className="pb-32"> {/* Increased padding to prevent overlap - changed from pb-24 to pb-32 */}
        {renderActiveScreen()}
      </main>
      
      {/* Bottom Navigation */}
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}