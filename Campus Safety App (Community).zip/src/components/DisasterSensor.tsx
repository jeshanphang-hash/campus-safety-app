import { Activity, Thermometer, Droplets, Wind, Zap, AlertCircle, TrendingUp, CheckCircle, Clock, MapPin } from 'lucide-react';
import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

export function DisasterSensor() {
  const [selectedIncident, setSelectedIncident] = useState<string | null>(null);

  const incidentReports = [
    {
      id: 'flood-001',
      type: 'weather',
      title: 'Flash Flood Warning',
      description: 'Heavy monsoon rains causing potential flooding',
      location: 'Campus Wide',
      status: 'active',
      severity: 'warning',
      reportedAt: '2 hours ago',
      lastUpdate: '30 min ago',
      affectedAreas: ['Library', 'Student Center', 'Parking Lots'],
      icon: Droplets
    },
    {
      id: 'power-002',
      type: 'infrastructure',
      title: 'Power Grid Maintenance',
      description: 'Scheduled power maintenance in progress',
      location: 'Engineering Building',
      status: 'resolved',
      severity: 'normal',
      reportedAt: '5 hours ago',
      lastUpdate: '1 hour ago',
      affectedAreas: ['Engineering Block A', 'Computer Labs'],
      icon: Zap
    },
    {
      id: 'water-003',
      type: 'infrastructure',
      title: 'Drainage System Monitoring',
      description: 'Monitoring drainage capacity during heavy rainfall',
      location: 'Basement Areas',
      status: 'monitoring',
      severity: 'warning',
      reportedAt: '1 hour ago',
      lastUpdate: '15 min ago',
      affectedAreas: ['Library Basement', 'Cafeteria Storage'],
      icon: Droplets
    },
    {
      id: 'haze-004',
      type: 'environmental',
      title: 'Haze Level Alert',
      description: 'Elevated haze levels from regional fires - API monitoring',
      location: 'Campus Wide',
      status: 'monitoring',
      severity: 'warning',
      reportedAt: '4 hours ago',
      lastUpdate: '1 hour ago',
      affectedAreas: ['All Buildings', 'Outdoor Areas'],
      icon: Wind
    },
    {
      id: 'heat-005',
      type: 'environmental',
      title: 'Heat Index Monitoring',
      description: 'Elevated heat index due to tropical climate - cooling stations active',
      location: 'Outdoor Areas',
      status: 'monitoring',
      severity: 'warning',
      reportedAt: '3 hours ago',
      lastUpdate: '1 hour ago',
      affectedAreas: ['Sports Complex', 'Parking Areas', 'Walkways'],
      icon: Thermometer
    }
  ];

  const getStatusColor = (status: string, severity: string) => {
    if (status === 'active' && severity === 'warning') return 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white';
    if (status === 'active' && severity === 'critical') return 'bg-gradient-to-r from-red-500 to-red-600 text-white';
    if (status === 'monitoring') return 'bg-gradient-to-r from-blue-500 to-blue-600 text-white';
    if (status === 'resolved' || status === 'completed') return 'bg-gradient-to-r from-green-500 to-green-600 text-white';
    return 'bg-gradient-to-r from-gray-400 to-gray-500 text-white';
  };

  const getStatusProgress = (status: string, severity: string) => {
    if (status === 'active' && severity === 'critical') return 90;
    if (status === 'active' && severity === 'warning') return 60;
    if (status === 'monitoring') return 45;
    if (status === 'resolved' || status === 'completed') return 100;
    return 30;
  };

  const getSensorCardBg = (status: string, severity: string) => {
    if (status === 'active' && severity === 'critical') return 'bg-gradient-to-br from-red-50 to-pink-50 border-red-200';
    if (status === 'active' && severity === 'warning') return 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200';
    if (status === 'monitoring') return 'bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200';
    if (status === 'resolved' || status === 'completed') return 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200';
    return 'bg-white border-gray-200';
  };

  const getIconBg = (status: string, severity: string) => {
    if (status === 'active' && severity === 'critical') return 'bg-red-100';
    if (status === 'active' && severity === 'warning') return 'bg-yellow-100';
    if (status === 'monitoring') return 'bg-blue-100';
    if (status === 'resolved' || status === 'completed') return 'bg-green-100';
    return 'bg-gray-100';
  };

  const getIconColor = (status: string, severity: string) => {
    if (status === 'active' && severity === 'critical') return 'text-red-600';
    if (status === 'active' && severity === 'warning') return 'text-yellow-600';
    if (status === 'monitoring') return 'text-blue-600';
    if (status === 'resolved' || status === 'completed') return 'text-green-600';
    return 'text-gray-600';
  };

  const activeIncidents = incidentReports.filter(report => report.status === 'active');
  const monitoringIncidents = incidentReports.filter(report => report.status === 'monitoring');
  const resolvedIncidents = incidentReports.filter(report => report.status === 'resolved' || report.status === 'completed');

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1626654700219-52b0d45d0969?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbGx1c3RyYXRlZCUyMHNjaG9vbCUyMGNhbXB1cyUyMGNvbG9yZnVsfGVufDF8fHx8MTc1NzIyNDE5MHww&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/90 to-blue-900/90"></div>
        <div className="relative flex items-center space-x-4">
          <img 
            src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
            alt="Campus Safety Logo" 
            className="w-12 h-12 object-contain"
          />
          <div className="space-y-2">
            <h1 className="text-2xl font-bold drop-shadow-lg">Campus Monitoring</h1>
            <p className="text-green-100 drop-shadow-md">Real-time incident tracking and safety status</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* Status Overview */}
        <Card className="p-6 bg-white shadow-lg">
          <h2 className="font-semibold mb-4 text-gray-800">Campus Status Overview</h2>
          <div className="grid grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-orange-500 rounded-full mx-auto mb-3 flex items-center justify-center">
                <span className="text-white font-bold">{activeIncidents.length}</span>
              </div>
              <p className="text-sm font-medium text-orange-600">Active</p>
              <p className="text-xs text-gray-500">Needs attention</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-full mx-auto mb-3 flex items-center justify-center">
                <span className="text-white font-bold">{monitoringIncidents.length}</span>
              </div>
              <p className="text-sm font-medium text-blue-600">Monitoring</p>
              <p className="text-xs text-gray-500">Under watch</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-500 rounded-full mx-auto mb-3 flex items-center justify-center">
                <span className="text-white font-bold">{resolvedIncidents.length}</span>
              </div>
              <p className="text-sm font-medium text-green-600">Resolved</p>
              <p className="text-xs text-gray-500">All clear</p>
            </div>
          </div>
        </Card>

        {/* Active Incidents */}
        {activeIncidents.length > 0 && (
          <Card className="p-5 bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200 shadow-lg">
            <div className="flex items-center space-x-4 mb-4">
              <div className="p-3 bg-yellow-100 rounded-full">
                <AlertCircle className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <h2 className="font-semibold text-yellow-800">Active Incidents</h2>
                <p className="text-sm text-yellow-600">Requiring immediate attention</p>
              </div>
            </div>
            <div className="space-y-3">
              {activeIncidents.map((incident) => (
                <div key={incident.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                  <div>
                    <span className="font-medium text-gray-800">{incident.title}</span>
                    <p className="text-sm text-gray-500">{incident.location}</p>
                  </div>
                  <TrendingUp className="h-5 w-5 text-yellow-500" />
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Incident Reports */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Campus Incident Reports</h2>
          <div className="space-y-4">
            {incidentReports.map((incident) => {
              const Icon = incident.icon;
              
              return (
                <Card key={incident.id} className={`p-6 shadow-lg ${getSensorCardBg(incident.status, incident.severity)}`}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className={`p-3 rounded-full ${getIconBg(incident.status, incident.severity)}`}>
                        <Icon className={`h-6 w-6 ${getIconColor(incident.status, incident.severity)}`} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-800">{incident.title}</h3>
                        <p className="text-sm text-gray-500">{incident.location}</p>
                      </div>
                    </div>
                    <Badge className={`${getStatusColor(incident.status, incident.severity)} shadow-md`}>
                      {incident.status.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="text-gray-700 mb-2">{incident.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>Reported {incident.reportedAt}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>{incident.affectedAreas.length} areas affected</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Response Status</span>
                        <span className={`font-medium ${getIconColor(incident.status, incident.severity)}`}>
                          Last updated: {incident.lastUpdate}
                        </span>
                      </div>
                      <Progress 
                        value={getStatusProgress(incident.status, incident.severity)} 
                        className="h-3"
                      />
                    </div>

                    <div className="flex justify-between items-center pt-2">
                      <div className="text-sm text-gray-500">
                        Affected: {incident.affectedAreas.join(', ')}
                      </div>
                      <Button
                        onClick={() => setSelectedIncident(selectedIncident === incident.id ? null : incident.id)}
                        variant="outline"
                        size="sm"
                      >
                        {selectedIncident === incident.id ? 'Hide Details' : 'View Details'}
                      </Button>
                    </div>

                    {selectedIncident === incident.id && (
                      <Card className="p-4 bg-white/80 border-gray-200 mt-4">
                        <h4 className="font-semibold text-gray-800 mb-2">Incident Details</h4>
                        <div className="space-y-2 text-sm text-gray-600">
                          <div><span className="font-medium">Incident ID:</span> {incident.id}</div>
                          <div><span className="font-medium">Type:</span> {incident.type}</div>
                          <div><span className="font-medium">Severity Level:</span> {incident.severity}</div>
                          <div><span className="font-medium">Affected Areas:</span></div>
                          <ul className="ml-4 space-y-1">
                            {incident.affectedAreas.map((area, idx) => (
                              <li key={idx}>• {area}</li>
                            ))}
                          </ul>
                        </div>
                      </Card>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <Card className="p-6 bg-gradient-to-br from-gray-50 to-blue-50 border-gray-200 shadow-lg">
          <h3 className="font-semibold text-gray-800 mb-4">Status Legend</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="h-4 w-4 bg-gradient-to-r from-red-400 to-orange-500 rounded-full"></div>
              <span className="text-gray-700">Active - Incident requiring immediate attention</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="h-4 w-4 bg-gradient-to-r from-blue-400 to-blue-500 rounded-full"></div>
              <span className="text-gray-700">Monitoring - Situation being closely watched</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="h-4 w-4 bg-gradient-to-r from-green-400 to-green-500 rounded-full"></div>
              <span className="text-gray-700">Resolved - Incident successfully handled</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}