import { Heart, Phone, MapPin, Clock, Search, ChevronRight, Stethoscope } from 'lucide-react';
import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

export function FirstAid() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProcedure, setSelectedProcedure] = useState<any>(null);

  const emergencyProcedures = [
    {
      id: 'cpr',
      title: 'CPR (Cardiopulmonary Resuscitation)',
      category: 'Cardiac',
      duration: '5-10 min',
      severity: 'critical',
      steps: [
        'Check responsiveness and breathing',
        'Call 999 immediately',
        'Place heel of hand on center of chest',
        'Push hard and fast at least 2 inches deep',
        'Allow complete chest recoil between compressions',
        'Give 30 compressions at 100-120 per minute',
        'Tilt head back, lift chin, give 2 rescue breaths',
        'Continue cycles of 30:2 until help arrives'
      ]
    },
    {
      id: 'choking',
      title: 'Choking (Heimlich Maneuver)',
      category: 'Respiratory',
      duration: '2-5 min',
      severity: 'critical',
      steps: [
        'Ask "Are you choking?" - if they can\'t speak, act immediately',
        'Stand behind the person',
        'Place arms around their waist',
        'Make a fist and place above navel',
        'Grasp fist with other hand',
        'Give quick upward thrusts',
        'Continue until object is expelled or person becomes unconscious',
        'If unconscious, begin CPR'
      ]
    },
    {
      id: 'bleeding',
      title: 'Severe Bleeding Control',
      category: 'Trauma',
      duration: '3-5 min',
      severity: 'high',
      steps: [
        'Apply direct pressure to wound with clean cloth',
        'Elevate injured area above heart if possible',
        'Do not remove embedded objects',
        'Apply pressure bandage over cloth',
        'If blood soaks through, add more layers',
        'Apply pressure to pressure points if needed',
        'Treat for shock - keep person warm and calm',
        'Get medical help immediately'
      ]
    },
    {
      id: 'burns',
      title: 'Burn Treatment',
      category: 'Thermal',
      duration: '10-15 min',
      severity: 'medium',
      steps: [
        'Remove person from heat source',
        'Cool burn with lukewarm water for 10-15 minutes',
        'Remove jewelry/clothing before swelling occurs',
        'Do not use ice or very cold water',
        'Cover with sterile, non-adhesive bandage',
        'Do not apply butter, oil, or other remedies',
        'Give pain medication if available',
        'Seek medical attention for severe burns'
      ]
    },
    {
      id: 'seizure',
      title: 'Seizure Response',
      category: 'Neurological',
      duration: '5-10 min',
      severity: 'medium',
      steps: [
        'Stay calm and time the seizure',
        'Clear area of dangerous objects',
        'Do not hold person down or put anything in mouth',
        'Place person on their side after seizure',
        'Stay with person until fully conscious',
        'Call 911 if seizure lasts over 5 minutes',
        'Check for medical alert bracelet',
        'Provide comfort and reassurance'
      ]
    },
    {
      id: 'sprain',
      title: 'Sprain/Strain Treatment (R.I.C.E.)',
      category: 'Musculoskeletal',
      duration: '20-30 min',
      severity: 'low',
      steps: [
        'Rest - Stop activity immediately',
        'Ice - Apply for 15-20 minutes every 2-3 hours',
        'Compression - Use elastic bandage (not too tight)',
        'Elevation - Raise injured area above heart level',
        'Take over-the-counter pain relievers',
        'Avoid HARM: Heat, Alcohol, Running, Massage',
        'Seek medical attention if severe pain persists',
        'Gradual return to activity after healing'
      ]
    }
  ];

  const emergencyContacts = [
    { name: 'Emergency Services', number: '999', type: 'emergency' },
    { name: 'Campus Security', number: '+60-3-2345-6789', type: 'security' },
    { name: 'PKU', number: '+60-3-2345-6700', type: 'health' },
    { name: 'Poison Control', number: '999', type: 'poison' }
  ];

  const filteredProcedures = emergencyProcedures.filter(procedure =>
    procedure.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    procedure.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-gradient-to-r from-red-500 to-red-600 text-white';
      case 'high': return 'bg-gradient-to-r from-orange-500 to-red-500 text-white';
      case 'medium': return 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white';
      default: return 'bg-gradient-to-r from-blue-500 to-blue-600 text-white';
    }
  };

  const getSeverityBg = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-gradient-to-br from-red-50 to-pink-50 border-red-200';
      case 'high': return 'bg-gradient-to-br from-orange-50 to-red-50 border-orange-200';
      case 'medium': return 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200';
      default: return 'bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200';
    }
  };

  const handleEmergencyCall = (number: string) => {
    alert(`Calling ${number}...`);
  };

  if (selectedProcedure) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-pink-50">
        {/* Header */}
        <div className="relative px-6 py-8 text-white">
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1649920442906-3c8ef428fb6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBzY2hvb2wlMjBpbGx1c3RyYXRpb24lMjBmdW58ZW58MXx8fHwxNzU3MjI0MTk0fDA&ixlib=rb-4.1.0&q=80&w=1080')`
            }}
          ></div>
          <div className="absolute inset-0 bg-gradient-to-r from-red-900/90 to-pink-900/90"></div>
          <div className="relative space-y-4">
            <Button 
              onClick={() => setSelectedProcedure(null)}
              variant="outline" 
              className="bg-white/20 border-white/30 text-white hover:bg-white/30 mb-4"
            >
              ← Back to Procedures
            </Button>
            <div className="flex items-center space-x-4">
              <img 
                src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
                alt="Campus Safety Logo" 
                className="w-12 h-12 object-contain"
              />
              <div>
                <h1 className="text-2xl font-bold drop-shadow-lg">{selectedProcedure.title}</h1>
                <p className="text-red-100 drop-shadow-md">Step-by-step emergency procedure</p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 pt-6 space-y-6">
          {/* Procedure Info */}
          <Card className={`p-6 shadow-lg ${getSeverityBg(selectedProcedure.severity)}`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-white rounded-full">
                  <Heart className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h2 className="font-semibold text-gray-800">{selectedProcedure.category}</h2>
                  <p className="text-gray-600">Estimated time: {selectedProcedure.duration}</p>
                </div>
              </div>
              <Badge className={getSeverityColor(selectedProcedure.severity)}>
                {selectedProcedure.severity.toUpperCase()}
              </Badge>
            </div>

            {/* Emergency Call Button */}
            <Button 
              onClick={() => handleEmergencyCall('999')}
              className="w-full h-14 bg-red-600 hover:bg-red-700 text-white font-bold text-lg mb-6"
              size="lg"
            >
              <Phone className="h-6 w-6 mr-2" />
              CALL 999 FIRST IF CRITICAL
            </Button>
          </Card>

          {/* Step-by-step Instructions */}
          <Card className="p-6 bg-white shadow-lg">
            <h3 className="font-semibold text-gray-800 mb-6">Step-by-Step Instructions</h3>
            <div className="space-y-4">
              {selectedProcedure.steps.map((step: string, index: number) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-700 leading-relaxed">{step}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Important Reminders */}
          <Card className="p-6 bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200 shadow-lg">
            <h3 className="font-semibold text-yellow-800 mb-4">Important Reminders</h3>
            <div className="space-y-2 text-sm text-yellow-700">
              <p>• Stay calm and work quickly but carefully</p>
              <p>• Call for professional help immediately if available</p>
              <p>• Continue procedures until professional help arrives</p>
              <p>• These are basic guidelines - seek proper first aid training</p>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-pink-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1649920442906-3c8ef428fb6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBzY2hvb2wlMjBpbGx1c3RyYXRpb24lMjBmdW58ZW58MXx8fHwxNzU3MjI0MTk0fDA&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/90 to-pink-900/90"></div>
        <div className="relative flex items-center space-x-4">
          <img 
            src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
            alt="Campus Safety Logo" 
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-2xl font-bold drop-shadow-lg">First Aid Guide</h1>
            <p className="text-red-100 drop-shadow-md">Emergency procedures and medical assistance</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* Emergency Contacts */}
        <Card className="p-6 bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg">
          <h2 className="font-semibold mb-4">Emergency Contacts</h2>
          <div className="grid grid-cols-2 gap-3">
            {emergencyContacts.map((contact, index) => (
              <Button
                key={index}
                onClick={() => handleEmergencyCall(contact.number)}
                className="bg-white/20 border-white/30 text-white hover:bg-white/30 h-auto p-3 flex flex-col items-center"
                variant="outline"
              >
                <Phone className="h-5 w-5 mb-1" />
                <span className="text-xs font-medium">{contact.name}</span>
              </Button>
            ))}
          </div>
        </Card>

        {/* Search */}
        <Card className="p-4 bg-white shadow-lg">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search procedures (e.g., CPR, choking, burns...)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        {/* Procedures List */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">
            Emergency Procedures ({filteredProcedures.length})
          </h2>
          
          {filteredProcedures.map((procedure) => (
            <Card 
              key={procedure.id} 
              className={`p-5 shadow-lg hover:shadow-xl transition-all duration-200 cursor-pointer ${getSeverityBg(procedure.severity)}`}
              onClick={() => setSelectedProcedure(procedure)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-white rounded-full">
                    <Heart className="h-6 w-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800 text-lg">{procedure.title}</h3>
                    <div className="flex items-center space-x-4 mt-1">
                      <div className="flex items-center space-x-1">
                        <Stethoscope className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-500">{procedure.category}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-500">{procedure.duration}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className={getSeverityColor(procedure.severity)}>
                    {procedure.severity.toUpperCase()}
                  </Badge>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Training Information */}
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 shadow-lg">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-blue-100 rounded-full">
              <Stethoscope className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-800 mb-2">Get Proper Training</h3>
              <p className="text-sm text-blue-700 leading-relaxed mb-3">
                This app provides basic guidance only. For comprehensive first aid training, contact:
              </p>
              <div className="space-y-1 text-sm text-blue-700">
                <p>• Campus Health Center: +1-555-HEALTH</p>
                <p>• Red Cross Training: redcross.org</p>
                <p>• CPR/AED Certification Classes</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}