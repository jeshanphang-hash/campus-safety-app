import { useState } from 'react';
import { Search, MapPin, Navigation2, Phone, AlertTriangle } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface CampusMapProps {
  onBack: () => void;
}

interface MapLocation {
  id: string;
  name: string;
  type: 'building' | 'emergency' | 'service';
  coordinates: { lat: number; lng: number };
  description: string;
}

export function CampusMap({ onBack }: CampusMapProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<MapLocation | null>(null);

  const locations: MapLocation[] = [
    {
      id: '1',
      name: 'Library Building',
      type: 'building',
      coordinates: { lat: 3.1390, lng: 101.6869 },
      description: 'Main campus library with 24/7 security'
    },
    {
      id: '2',
      name: 'Emergency Station A',
      type: 'emergency',
      coordinates: { lat: 3.1400, lng: 101.6879 },
      description: 'Emergency call station with direct line to campus security'
    },
    {
      id: '3',
      name: 'Campus Security Office',
      type: 'service',
      coordinates: { lat: 3.1380, lng: 101.6859 },
      description: 'Main security office - 24/7 staffed with CCTV monitoring'
    },
    {
      id: '4',
      name: 'Student Center',
      type: 'building',
      coordinates: { lat: 3.1410, lng: 101.6889 },
      description: 'Student services and safe gathering area during emergencies'
    },
    {
      id: '5',
      name: 'Emergency Station B',
      type: 'emergency',
      coordinates: { lat: 3.1370, lng: 101.6849 },
      description: 'Emergency call station near parking area with flood monitoring'
    },
    {
      id: '6',
      name: 'Weather Monitoring Station',
      type: 'service',
      coordinates: { lat: 3.1420, lng: 101.6899 },
      description: 'Air quality and weather monitoring station for haze and heat index alerts'
    }
  ];

  const filteredLocations = locations.filter(location =>
    location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    location.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getLocationIcon = (type: string) => {
    switch (type) {
      case 'emergency':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'service':
        return <Phone className="h-5 w-5 text-blue-500" />;
      default:
        return <MapPin className="h-5 w-5 text-green-500" />;
    }
  };

  const getLocationColor = (type: string) => {
    switch (type) {
      case 'emergency':
        return 'border-red-200 bg-red-50';
      case 'service':
        return 'border-blue-200 bg-blue-50';
      default:
        return 'border-green-200 bg-green-50';
    }
  };

  const handleNavigate = (location: MapLocation) => {
    // In a real app, this would open navigation app
    alert(`Navigating to ${location.name}...`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1626654700219-52b0d45d0969?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbGx1c3RyYXRlZCUyMHNjaG9vbCUyMGNhbXB1cyUyMGNvbG9yZnVsfGVufDF8fHx8MTc1NzIyNDE5MHww&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/80 to-blue-900/80"></div>
        <div className="relative flex items-center space-x-4">
          <img 
            src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
            alt="Campus Safety Logo" 
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-2xl font-bold drop-shadow-lg">Campus Map</h1>
            <p className="text-green-100 drop-shadow-md">Find locations and emergency stations</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* Back Button */}
        <Button onClick={onBack} variant="outline" className="mb-4">
          ← Back to Home
        </Button>

        {/* Search Bar */}
        <Card className="p-4 bg-white shadow-lg">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search for buildings, emergency stations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        {/* Map Placeholder */}
        <Card className="p-6 bg-gradient-to-br from-blue-100 to-green-100 shadow-lg">
          <div className="aspect-video bg-gradient-to-br from-blue-200 to-green-200 rounded-lg flex items-center justify-center relative overflow-hidden">
            {/* Simulated map with location pins */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-gray-600">
                <MapPin className="h-12 w-12 mx-auto mb-4 text-blue-500" />
                <p className="font-semibold">Interactive Campus Map</p>
                <p className="text-sm">Showing {filteredLocations.length} locations</p>
              </div>
            </div>
            
            {/* Sample location pins */}
            <div className="absolute top-4 left-8 w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
            <div className="absolute top-12 right-12 w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg"></div>
            <div className="absolute bottom-8 left-16 w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-lg"></div>
            <div className="absolute bottom-16 right-8 w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
          </div>
        </Card>

        {/* Current Location */}
        <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 shadow-lg">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-blue-100 rounded-full">
              <Navigation2 className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-800">Your Current Location</h3>
              <p className="text-blue-600">Main Campus - Library Area</p>
            </div>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white ml-auto">
              Share Location
            </Button>
          </div>
        </Card>



        {/* Selected Location Details */}
        {selectedLocation && (
          <Card className="p-6 bg-gradient-to-br from-gray-50 to-blue-50 border-gray-200 shadow-lg">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4">
                <div className="p-3 bg-white rounded-full">
                  {getLocationIcon(selectedLocation.type)}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 text-lg">{selectedLocation.name}</h3>
                  <p className="text-gray-600 mt-1">{selectedLocation.description}</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Coordinates: {selectedLocation.coordinates.lat.toFixed(4)}, {selectedLocation.coordinates.lng.toFixed(4)}
                  </p>
                </div>
              </div>
              <Button
                onClick={() => setSelectedLocation(null)}
                variant="outline"
                size="sm"
              >
                ✕
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}