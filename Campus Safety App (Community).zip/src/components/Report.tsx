import { useState } from 'react';
import { Camera, MapPin, AlertTriangle, Send, Phone } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';

export function Report() {
  const [formData, setFormData] = useState({
    type: '',
    location: '',
    description: '',
    anonymous: false
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const incidentTypes = [
    'Security Threat',
    'Medical Emergency',
    'Fire/Smoke',
    'Suspicious Activity',
    'Harassment',
    'Property Damage',
    'Environmental Hazard',
    'Other'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    alert('Report submitted successfully. Campus security has been notified.');
    setFormData({ type: '', location: '', description: '', anonymous: false });
    setIsSubmitting(false);
  };

  const handleLocationCapture = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setFormData(prev => ({ 
            ...prev, 
            location: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}` 
          }));
          alert('Location captured successfully!');
        },
        (error) => {
          alert('Unable to capture location. Please enter manually.');
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const handlePhotoCapture = () => {
    alert('Photo capture functionality would open camera here.');
  };

  const handleEmergencyCall = () => {
    alert('Calling 999...');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1626654700219-52b0d45d0969?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbGx1c3RyYXRlZCUyMHNjaG9vbCUyMGNhbXB1cyUyMGNvbG9yZnVsfGVufDF8fHx8MTc1NzIyNDE5MHww&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-orange-900/90 to-red-900/90"></div>
        <div className="relative flex items-center space-x-4">
          <img 
            src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
            alt="Campus Safety Logo" 
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-2xl font-bold drop-shadow-lg">Report Incident</h1>
            <p className="text-orange-100 drop-shadow-md">Help keep our campus safe by reporting incidents</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* Emergency Notice */}
        <Card className="p-5 bg-gradient-to-r from-red-50 to-orange-50 border-red-200 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-red-100 rounded-full">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-red-800">Emergency Situation?</h3>
                <p className="text-sm text-red-600">For immediate emergencies, call 999 first</p>
              </div>
            </div>
            <Button 
              onClick={handleEmergencyCall}
              className="bg-red-600 hover:bg-red-700 text-white font-bold"
            >
              <Phone className="h-4 w-4 mr-2" />
              Call 999
            </Button>
          </div>
        </Card>

        {/* Report Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Incident Type */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="space-y-4">
              <Label className="text-lg font-semibold text-gray-800">What type of incident are you reporting?</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                <SelectTrigger className="w-full h-12">
                  <SelectValue placeholder="Select incident type" />
                </SelectTrigger>
                <SelectContent>
                  {incidentTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </Card>

          {/* Location */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="space-y-4">
              <Label className="text-lg font-semibold text-gray-800">Where did this incident occur?</Label>
              <div className="flex gap-3">
                <Input
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="Building name, room number, or address"
                  className="flex-1 h-12"
                />
                <Button
                  type="button"
                  onClick={handleLocationCapture}
                  variant="outline"
                  className="h-12 px-4 bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100"
                >
                  <MapPin className="h-5 w-5" />
                </Button>
              </div>
              <p className="text-sm text-gray-500">Click the location icon to use your current GPS coordinates</p>
            </div>
          </Card>

          {/* Description */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="space-y-4">
              <Label className="text-lg font-semibold text-gray-800">Describe what happened</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Please provide as much detail as possible about the incident, including time, people involved, and any other relevant information..."
                rows={6}
                className="resize-none"
              />
            </div>
          </Card>

          {/* Photo/Evidence */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="space-y-4">
              <Label className="text-lg font-semibold text-gray-800">Add photo evidence (optional)</Label>
              <Button
                type="button"
                onClick={handlePhotoCapture}
                variant="outline"
                className="w-full h-16 bg-gray-50 border-gray-200 hover:bg-gray-100"
              >
                <Camera className="h-6 w-6 mr-3 text-gray-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-800">Take Photo</p>
                  <p className="text-sm text-gray-500">Capture evidence of the incident</p>
                </div>
              </Button>
            </div>
          </Card>

          {/* Anonymous Reporting */}
          <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 shadow-lg">
            <div className="flex items-start space-x-4">
              <input
                type="checkbox"
                id="anonymous"
                checked={formData.anonymous}
                onChange={(e) => setFormData(prev => ({ ...prev, anonymous: e.target.checked }))}
                className="mt-1 h-5 w-5 text-blue-600"
              />
              <div>
                <Label htmlFor="anonymous" className="font-semibold text-blue-800 cursor-pointer">
                  Submit this report anonymously
                </Label>
                <p className="text-sm text-blue-600 mt-1">
                  Your identity will not be shared, but this may limit our ability to follow up with you for additional information.
                </p>
              </div>
            </div>
          </Card>

          {/* Submit Button */}
          <Card className="p-6 bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg">
            <div className="space-y-4">
              <Button
                type="submit"
                disabled={isSubmitting || !formData.type || !formData.location || !formData.description}
                className="w-full h-16 bg-white/20 border-white/30 text-white hover:bg-white/30 font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed"
                size="lg"
              >
                {isSubmitting ? (
                  <div className="flex items-center">
                    <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-3"></div>
                    Submitting Report...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <Send className="h-6 w-6 mr-3" />
                    Submit Report
                  </div>
                )}
              </Button>
              <div className="text-center text-sm text-white/80">
                <p>Your report will be immediately sent to campus security</p>
                <p>Emergency services will be contacted if necessary</p>
              </div>
            </div>
          </Card>
        </form>

        {/* Contact Information */}
        <Card className="p-6 bg-gradient-to-br from-gray-50 to-blue-50 border-gray-200 shadow-lg">
          <h3 className="font-semibold text-gray-800 mb-4">Need to speak with someone immediately?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Campus Security</h4>
              <p className="text-gray-600">+60-3-2345-6789</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Counseling Services</h4>
              <p className="text-gray-600">+60-3-2345-6701</p>
              <p className="text-sm text-gray-500">Mon-Fri 8AM-5PM</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}