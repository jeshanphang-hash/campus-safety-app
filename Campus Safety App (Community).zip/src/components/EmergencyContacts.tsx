import { useState } from 'react';
import { Phone, UserPlus, Edit, Trash2, Save, X } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface Contact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}

interface EmergencyContactsProps {
  onBack: () => void;
}

export function EmergencyContacts({ onBack }: EmergencyContactsProps) {
  const [contacts, setContacts] = useState<Contact[]>([
    { id: '1', name: 'Mom', phone: '+60-12-345-6789', relationship: 'Parent' },
    { id: '2', name: 'Campus Security', phone: '+60-3-2345-6789', relationship: 'Security' },
    { id: '3', name: 'Malaysia Emergency', phone: '999', relationship: 'Emergency Services' }
  ]);
  
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newContact, setNewContact] = useState({ name: '', phone: '', relationship: '' });

  const handleAdd = () => {
    if (newContact.name && newContact.phone && newContact.relationship) {
      const id = Date.now().toString();
      setContacts([...contacts, { ...newContact, id }]);
      setNewContact({ name: '', phone: '', relationship: '' });
      setIsAdding(false);
    }
  };

  const handleEdit = (contact: Contact) => {
    setEditingId(contact.id);
    setNewContact({ name: contact.name, phone: contact.phone, relationship: contact.relationship });
  };

  const handleSaveEdit = () => {
    setContacts(contacts.map(c => 
      c.id === editingId ? { ...c, ...newContact } : c
    ));
    setEditingId(null);
    setNewContact({ name: '', phone: '', relationship: '' });
  };

  const handleDelete = (id: string) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  const handleCall = (phone: string) => {
    // In a real app, this would initiate a call
    alert(`Calling ${phone}...`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1599666882726-fe28581e3147?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJ0b29uJTIwc2Nob29sJTIwYnVpbGRpbmclMjBlZHVjYXRpb258ZW58MXx8fHwxNzU3MjI0MTg2fDA&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-purple-900/80"></div>
        <div className="relative flex items-center space-x-4">
          <img 
            src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
            alt="Campus Safety Logo" 
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-2xl font-bold drop-shadow-lg">Emergency Contacts</h1>
            <p className="text-blue-100 drop-shadow-md">Manage your emergency contacts</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* Back Button */}
        <Button onClick={onBack} variant="outline" className="mb-4">
          ← Back to Home
        </Button>

        {/* Add Contact Button */}
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Your Emergency Contacts</h2>
          <Button 
            onClick={() => setIsAdding(true)}
            className="bg-gradient-to-r from-blue-500 to-purple-500 text-white"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Add Contact
          </Button>
        </div>

        {/* Add/Edit Form */}
        {(isAdding || editingId) && (
          <Card className="p-6 bg-white shadow-lg">
            <h3 className="font-semibold mb-4">
              {isAdding ? 'Add New Contact' : 'Edit Contact'}
            </h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  placeholder="Contact name"
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  placeholder="+1-555-0000"
                />
              </div>
              <div>
                <Label htmlFor="relationship">Relationship</Label>
                <Input
                  id="relationship"
                  value={newContact.relationship}
                  onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
                  placeholder="Parent, Friend, Security, etc."
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={isAdding ? handleAdd : handleSaveEdit}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button 
                  onClick={() => {
                    setIsAdding(false);
                    setEditingId(null);
                    setNewContact({ name: '', phone: '', relationship: '' });
                  }}
                  variant="outline"
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Contacts List */}
        <div className="space-y-4">
          {contacts.map((contact) => (
            <Card key={contact.id} className="p-6 bg-white shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <Phone className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">{contact.name}</h3>
                    <p className="text-gray-600">{contact.phone}</p>
                    <p className="text-sm text-gray-500">{contact.relationship}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleCall(contact.phone)}
                    className="bg-green-500 hover:bg-green-600 text-white"
                    size="sm"
                  >
                    <Phone className="h-4 w-4" />
                  </Button>
                  <Button
                    onClick={() => handleEdit(contact)}
                    variant="outline"
                    size="sm"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    onClick={() => handleDelete(contact.id)}
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}