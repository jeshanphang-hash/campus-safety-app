import { Bell, MapPin, Shield, User, Moon, Smartphone, HelpCircle, LogOut, Settings as SettingsIcon } from 'lucide-react';
import { useState } from 'react';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Button } from './ui/button';
import { Separator } from './ui/separator';

interface SettingsProps {
  onLogout: () => void;
}

export function Settings({ onLogout }: SettingsProps) {
  const [settings, setSettings] = useState({
    notifications: {
      emergencyAlerts: true,
      maintenanceUpdates: true,
      pushNotifications: true
    },
    privacy: {
      locationSharing: true,
      anonymousReporting: false
    },
    accessibility: {
      darkMode: false,
      largeText: false,
      highContrast: false
    }
  });

  const updateSetting = (category: string, key: string, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [key]: value
      }
    }));
  };

  const settingSections = [
    {
      title: 'Notifications',
      icon: Bell,
      color: 'from-yellow-500 to-orange-500',
      items: [
        {
          key: 'emergencyAlerts',
          label: 'Emergency Alerts',
          description: 'Critical safety notifications',
          value: settings.notifications.emergencyAlerts,
          category: 'notifications'
        },
        {
          key: 'maintenanceUpdates',
          label: 'Maintenance Updates',
          description: 'Building and facility updates',
          value: settings.notifications.maintenanceUpdates,
          category: 'notifications'
        },
        {
          key: 'pushNotifications',
          label: 'Push Notifications',
          description: 'Allow app to send notifications',
          value: settings.notifications.pushNotifications,
          category: 'notifications'
        }
      ]
    },
    {
      title: 'Privacy & Security',
      icon: Shield,
      color: 'from-blue-500 to-purple-500',
      items: [
        {
          key: 'locationSharing',
          label: 'Location Sharing',
          description: 'Share location for emergency response',
          value: settings.privacy.locationSharing,
          category: 'privacy'
        },
        {
          key: 'anonymousReporting',
          label: 'Anonymous by Default',
          description: 'Make reports anonymous by default',
          value: settings.privacy.anonymousReporting,
          category: 'privacy'
        }
      ]
    },
    {
      title: 'Accessibility',
      icon: User,
      color: 'from-green-500 to-teal-500',
      items: [
        {
          key: 'darkMode',
          label: 'Dark Mode',
          description: 'Use dark theme',
          value: settings.accessibility.darkMode,
          category: 'accessibility'
        },
        {
          key: 'largeText',
          label: 'Large Text',
          description: 'Increase text size for better readability',
          value: settings.accessibility.largeText,
          category: 'accessibility'
        },
        {
          key: 'highContrast',
          label: 'High Contrast',
          description: 'Increase contrast for better visibility',
          value: settings.accessibility.highContrast,
          category: 'accessibility'
        }
      ]
    }
  ];

  const actionItems = [
    {
      icon: MapPin,
      label: 'Test Location Services',
      description: 'Verify location accuracy',
      color: 'text-blue-600',
      action: () => alert('Location test initiated')
    },
    {
      icon: Smartphone,
      label: 'Test Emergency Alerts',
      description: 'Send test notification',
      color: 'text-orange-600',
      action: () => alert('Test alert sent')
    },
    {
      icon: HelpCircle,
      label: 'Help & Support',
      description: 'Get help using the app',
      color: 'text-green-600',
      action: () => alert('Help center opened')
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1649920442906-3c8ef428fb6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBzY2hvb2wlMjBpbGx1c3RyYXRpb24lMjBmdW58ZW58MXx8fHwxNzU3MjI0MTk0fDA&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/90 to-gray-800/90"></div>
        <div className="relative flex items-center space-x-4">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center p-1 shadow-lg">
            <img 
              src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
              alt="Campus Safety Logo" 
              className="w-10 h-10 object-cover rounded-full"
            />
          </div>
          <div>
            <h1 className="text-2xl font-bold drop-shadow-lg">Settings</h1>
            <p className="text-gray-200 drop-shadow-md">Customize your safety app experience</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* User Profile */}
        <Card className="p-6 bg-white shadow-lg">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <User className="h-8 w-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-800">Student User</h3>
              <p className="text-gray-500">student@university.edu</p>
              <p className="text-sm text-gray-400">Student ID: 12345678</p>
            </div>
            <Button variant="outline" className="bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100">
              Edit Profile
            </Button>
          </div>
        </Card>

        {/* Settings Sections */}
        {settingSections.map((section, sectionIndex) => {
          const Icon = section.icon;
          
          return (
            <div key={sectionIndex} className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className={`p-3 bg-gradient-to-r ${section.color} rounded-full`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h2 className="font-semibold text-xl text-gray-800">{section.title}</h2>
              </div>
              
              <Card className="p-6 bg-white shadow-lg space-y-6">
                {section.items.map((item, itemIndex) => (
                  <div key={itemIndex}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-800">{item.label}</h4>
                        <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                      </div>
                      <Switch
                        checked={item.value}
                        onCheckedChange={(checked) => updateSetting(item.category, item.key, checked)}
                        className="ml-4"
                      />
                    </div>
                    {itemIndex < section.items.length - 1 && <Separator className="mt-6" />}
                  </div>
                ))}
              </Card>
            </div>
          );
        })}

        {/* Actions */}
        <div className="space-y-4">
          <h2 className="font-semibold text-xl text-gray-800">Quick Actions</h2>
          <Card className="p-6 bg-white shadow-lg space-y-4">
            {actionItems.map((item, index) => {
              const Icon = item.icon;
              
              return (
                <div key={index}>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start p-4 h-auto hover:bg-gray-50"
                    onClick={item.action}
                  >
                    <div className="flex items-center space-x-4 w-full">
                      <div className="p-3 bg-gray-100 rounded-full">
                        <Icon className={`h-6 w-6 ${item.color}`} />
                      </div>
                      <div className="text-left flex-1">
                        <p className="font-semibold text-gray-800">{item.label}</p>
                        <p className="text-sm text-gray-500">{item.description}</p>
                      </div>
                    </div>
                  </Button>
                  {index < actionItems.length - 1 && <Separator className="mt-4" />}
                </div>
              );
            })}
          </Card>
        </div>

        {/* App Info */}
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 shadow-lg">
          <div className="space-y-3">
            <h3 className="font-semibold text-blue-800">Campus Safety App</h3>
            <div className="text-sm text-blue-600 space-y-2">
              <div className="flex justify-between">
                <span>Version</span>
                <span className="font-medium">1.0.0</span>
              </div>
              <div className="flex justify-between">
                <span>Last updated</span>
                <span className="font-medium">January 7, 2025</span>
              </div>
              <div className="flex justify-between">
                <span>Developer</span>
                <span className="font-medium">Team Lucky</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Sign Out */}
        <Button 
          variant="outline" 
          className="w-full h-12 border-red-200 text-red-600 hover:bg-red-50 mb-8"
          onClick={onLogout}
        >
          <LogOut className="h-5 w-5 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}