import { Home, Megaphone, AlertTriangle, Activity, Heart, Settings } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const tabs = [
    { id: 'home', icon: Home, label: 'Home', color: 'text-blue-600' },
    { id: 'announcements', icon: Megaphone, label: 'Alerts', color: 'text-yellow-600' },
    { id: 'report', icon: AlertTriangle, label: 'Report', color: 'text-red-600' },
    { id: 'disaster', icon: Activity, label: 'Sensors', color: 'text-green-600' },
    { id: 'firstaid', icon: Heart, label: 'First Aid', color: 'text-pink-600' },
    { id: 'settings', icon: Settings, label: 'Settings', color: 'text-gray-600' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-gray-200 shadow-lg z-50"> {/* Added z-50 for proper stacking */}
      <div className="flex justify-around items-center py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center p-2 min-w-0 transition-all duration-200 ${
                isActive 
                  ? `${tab.color} scale-105` 
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <div className={`p-1.5 rounded-full transition-all duration-200 ${
                isActive ? 'bg-current/10' : ''
              }`}>
                <Icon className="h-4 w-4" />
              </div>
              <span className="text-xs font-medium mt-0.5">{tab.label}</span>
              {isActive && (
                <div className="w-3 h-0.5 bg-current rounded-full mt-0.5"></div>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}