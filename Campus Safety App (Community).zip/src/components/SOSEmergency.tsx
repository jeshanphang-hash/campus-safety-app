import { useState, useEffect } from 'react';
import { Phone, Mic, MicOff, Shield, Bot, Users, AlertTriangle, MapPin, Clock } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

interface SOSEmergencyProps {
  onBack: () => void;
}

export function SOSEmergency({ onBack }: SOSEmergencyProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [sosActivated, setSosActivated] = useState(false);
  const [aiCallerActive, setAiCallerActive] = useState(false);
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } else {
      setRecordingTime(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  useEffect(() => {
    let countdownInterval: NodeJS.Timeout;
    if (countdown > 0) {
      countdownInterval = setInterval(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(countdownInterval);
  }, [countdown]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSOSActivation = () => {
    setSosActivated(true);
    setCountdown(10); // 10 second countdown
    setTimeout(() => {
      if (sosActivated) {
        // Auto-call emergency services
        handleEmergencyCall('999');
      }
    }, 10000);
  };

  const handleCancelSOS = () => {
    setSosActivated(false);
    setCountdown(0);
  };

  const handleEmergencyCall = (number: string) => {
    alert(`Calling ${number}... Emergency services contacted!`);
    // In a real app, this would initiate an actual call
  };

  const handleAICaller = () => {
    setAiCallerActive(true);
    alert('AI Caller activated! A realistic conversation will be initiated to ensure your safety during rides.');
    setTimeout(() => {
      setAiCallerActive(false);
    }, 30000); // 30 second demo
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      alert('Recording started - audio will be automatically saved and shared with emergency contacts if needed.');
    } else {
      alert('Recording stopped and saved securely.');
    }
  };

  const handleRoboticCall = (service: string) => {
    alert(`Automated call initiated to ${service}. A robotic voice will explain your situation and request assistance.`);
  };

  const emergencyContacts = [
    { name: 'Campus Security', number: '+60-3-2345-6789' },
    { name: 'Malaysia Emergency', number: '999' },
    { name: 'Emergency Medical', number: '999' },
    { name: 'Mom', number: '+60-12-345-6789' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50">
      {/* Header */}
      <div className="relative px-6 py-8 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1649920442906-3c8ef428fb6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBzY2hvb2wlMjBpbGx1c3RyYXRpb24lMjBmdW58ZW58MXx8fHwxNzU3MjI0MTk0fDA&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/80 to-orange-900/80"></div>
        <div className="relative flex items-center space-x-4">
          <img 
            src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
            alt="Campus Safety Logo" 
            className="w-12 h-12 object-contain"
          />
          <div>
            <h1 className="text-2xl font-bold drop-shadow-lg">SOS Emergency</h1>
            <p className="text-red-100 drop-shadow-md">Your safety tools in one place</p>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-6">
        {/* Back Button */}
        <Button onClick={onBack} variant="outline" className="mb-4">
          ← Back to Home
        </Button>

        {/* SOS Button */}
        {!sosActivated ? (
          <Card className="p-8 bg-gradient-to-br from-red-500 to-red-600 text-white shadow-lg">
            <div className="text-center space-y-6">
              <div className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full mx-auto flex items-center justify-center">
                <AlertTriangle className="h-12 w-12 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-2">Emergency SOS</h2>
                <p className="text-red-100">Press and hold for 3 seconds to activate emergency protocol</p>
              </div>
              <Button
                onClick={handleSOSActivation}
                className="w-full h-16 bg-white text-red-600 hover:bg-red-50 font-bold text-lg"
                size="lg"
              >
                ACTIVATE SOS
              </Button>
            </div>
          </Card>
        ) : (
          <Card className="p-8 bg-gradient-to-br from-red-600 to-red-700 text-white shadow-lg">
            <div className="text-center space-y-6">
              <div className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full mx-auto flex items-center justify-center animate-pulse">
                <Clock className="h-12 w-12 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-2">SOS ACTIVATED</h2>
                <p className="text-red-100 mb-4">Emergency call will be made in:</p>
                <div className="text-6xl font-bold mb-4">{countdown}</div>
                <Progress value={(10 - countdown) * 10} className="w-full h-4 mb-4" />
                <p className="text-sm text-red-200">Your location is being shared with emergency contacts</p>
              </div>
              <Button
                onClick={handleCancelSOS}
                className="w-full h-16 bg-white text-red-600 hover:bg-red-50 font-bold text-lg"
                size="lg"
              >
                CANCEL SOS
              </Button>
            </div>
          </Card>
        )}

        {/* Quick Emergency Tools */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Emergency Tools</h2>
          
          {/* Voice Recording */}
          <Card className="p-6 bg-white shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-full ${isRecording ? 'bg-red-100' : 'bg-blue-100'}`}>
                  {isRecording ? 
                    <MicOff className={`h-6 w-6 ${isRecording ? 'text-red-600' : 'text-blue-600'}`} /> :
                    <Mic className={`h-6 w-6 ${isRecording ? 'text-red-600' : 'text-blue-600'}`} />
                  }
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">Emergency Recording</h3>
                  <p className="text-gray-600 text-sm">
                    {isRecording ? `Recording: ${formatTime(recordingTime)}` : 'Record evidence or emergency message'}
                  </p>
                </div>
              </div>
              <Button
                onClick={toggleRecording}
                className={`${isRecording ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'} text-white`}
              >
                {isRecording ? 'Stop' : 'Record'}
              </Button>
            </div>
          </Card>

          {/* AI Caller */}
          <Card className="p-6 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-full ${aiCallerActive ? 'bg-purple-100' : 'bg-gray-100'}`}>
                  <Bot className={`h-6 w-6 ${aiCallerActive ? 'text-purple-600' : 'text-gray-600'}`} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">AI Safety Caller</h3>
                  <p className="text-gray-600 text-sm">
                    {aiCallerActive ? 'AI caller is active - stay safe!' : 'Activate realistic AI conversation for ride safety'}
                  </p>
                </div>
              </div>
              <Button
                onClick={handleAICaller}
                disabled={aiCallerActive}
                className={`${aiCallerActive ? 'bg-gray-400' : 'bg-purple-500 hover:bg-purple-600'} text-white`}
              >
                {aiCallerActive ? 'Active' : 'Activate'}
              </Button>
            </div>
          </Card>

          {/* Location Sharing */}
          <Card className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-green-100 rounded-full">
                  <MapPin className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">Live Location Sharing</h3>
                  <p className="text-gray-600 text-sm">Share your real-time location with trusted contacts</p>
                </div>
              </div>
              <Button className="bg-green-500 hover:bg-green-600 text-white">
                Share Now
              </Button>
            </div>
          </Card>
        </div>

        {/* Emergency Contacts Quick Call */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Emergency Contacts</h2>
          <div className="grid grid-cols-1 gap-3">
            {emergencyContacts.map((contact, index) => (
              <Card key={index} className="p-4 bg-white shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <Phone className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800">{contact.name}</h4>
                      <p className="text-gray-600 text-sm">{contact.number}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleEmergencyCall(contact.number)}
                      className="bg-green-500 hover:bg-green-600 text-white"
                      size="sm"
                    >
                      Call
                    </Button>
                    <Button
                      onClick={() => handleRoboticCall(contact.name)}
                      variant="outline"
                      size="sm"
                      className="text-purple-600 border-purple-200 hover:bg-purple-50"
                    >
                      <Bot className="h-4 w-4 mr-1" />
                      Auto Call
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Safety Instructions */}
        <Card className="p-6 bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200 shadow-lg">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-yellow-100 rounded-full">
              <Shield className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <h3 className="font-semibold text-yellow-800 mb-2">Emergency Protocol</h3>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• SOS button will call emergency services after 10-second countdown</li>
                <li>• AI Caller creates realistic conversations for ride safety</li>
                <li>• Recording feature automatically saves evidence securely</li>
                <li>• Location sharing allows real-time tracking by trusted contacts</li>
                <li>• Robotic calls can alert services even if you can't speak</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}