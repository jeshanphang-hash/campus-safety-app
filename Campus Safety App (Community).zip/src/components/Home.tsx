import { AlertTriangle, Megaphone, Heart, Activity, Phone, MapPin, Shield, Users, Map } from 'lucide-react';
import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { EmergencyContacts } from './EmergencyContacts';
import { CampusMap } from './CampusMap';
import { SOSEmergency } from './SOSEmergency';

interface HomeProps {
  onNavigate: (tab: string) => void;
}

export function Home({ onNavigate }: HomeProps) {
  const [activeView, setActiveView] = useState<'home' | 'contacts' | 'map' | 'sos'>('home');

  const quickActions = [
    { id: 'sos', icon: Phone, label: 'SOS Emergency', color: 'bg-gradient-to-br from-red-500 to-red-600 text-white shadow-lg shadow-red-500/25' },
    { id: 'report', icon: AlertTriangle, label: 'Report Incident', color: 'bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-lg shadow-orange-500/25' },
    { id: 'firstaid', icon: Heart, label: 'First Aid', color: 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/25' },
    { id: 'disaster', icon: Activity, label: 'Disaster Sensors', color: 'bg-gradient-to-br from-green-500 to-green-600 text-white shadow-lg shadow-green-500/25' }
  ];

  const mapActions = [
    { id: 'map', icon: Map, label: 'Campus Map', color: 'bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/25' },
    { id: 'contacts', icon: Users, label: 'Emergency Contacts', color: 'bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-lg shadow-indigo-500/25' }
  ];

  const handleQuickAction = (actionId: string) => {
    if (actionId === 'sos') {
      setActiveView('sos');
    } else if (actionId === 'contacts') {
      setActiveView('contacts');
    } else if (actionId === 'map') {
      setActiveView('map');
    } else {
      onNavigate(actionId);
    }
  };

  // Show different views based on activeView state
  if (activeView === 'contacts') {
    return <EmergencyContacts onBack={() => setActiveView('home')} />;
  }
  
  if (activeView === 'map') {
    return <CampusMap onBack={() => setActiveView('home')} />;
  }
  
  if (activeView === 'sos') {
    return <SOSEmergency onBack={() => setActiveView('home')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header with Hero Section */}
      <div className="relative px-6 pt-8 pb-6 min-h-[200px]">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1599666882726-fe28581e3147?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJ0b29uJTIwc2Nob29sJTIwYnVpbGRpbmclMjBlZHVjYXRpb258ZW58MXx8fHwxNzU3MjI0MTg2fDA&ixlib=rb-4.1.0&q=80&w=1080')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-purple-900/80"></div>
        <div className="relative text-center space-y-3 text-white">
          <div className="mx-auto w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 p-1 shadow-lg overflow-hidden">
            <img 
              src="https://i.ibb.co/3mcqsssw/11-ezgif-com-webp-to-png-converter.png" 
              alt="Campus Safety Logo" 
              className="w-16 h-16 object-cover rounded-full"
            />
          </div>
          <h1 className="text-3xl font-bold drop-shadow-lg">Campus Safety</h1>
          <p className="text-blue-100 drop-shadow-md">Your safety is our priority</p>
        </div>
      </div>

      <div className="px-6 pt-6 space-y-8">
        {/* Emergency Alert */}
        <Card className="p-5 bg-gradient-to-r from-red-50 to-orange-50 border-red-200 shadow-lg">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-red-100 rounded-full">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-red-800">Campus Alert Active</h3>
              <p className="text-sm text-red-600">Flash flood warning due to heavy monsoon rains</p>
            </div>
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
          </div>
        </Card>

        {/* SOS Emergency Button - Prominently Featured */}
        <Card className="p-6 bg-gradient-to-br from-red-500 to-red-600 text-white shadow-xl">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full mx-auto flex items-center justify-center">
              <Phone className="h-8 w-8 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Emergency SOS</h2>
              <p className="text-red-100">Instant access to emergency services</p>
            </div>
            <Button
              onClick={() => handleQuickAction('sos')}
              className="w-full h-14 bg-white text-red-600 hover:bg-red-50 font-bold text-lg"
              size="lg"
            >
              ACTIVATE SOS
            </Button>
          </div>
        </Card>

        {/* Quick Actions */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.id}
                  onClick={() => handleQuickAction(action.id)}
                  className={`h-28 flex flex-col space-y-3 border-0 transition-all duration-200 hover:scale-105 ${action.color}`}
                >
                  <Icon className="h-7 w-7" />
                  <span className="text-sm font-medium">{action.label}</span>
                </Button>
              );
            })}
          </div>
        </div>

        {/* Campus Tools */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Campus Tools</h2>
          <div className="grid grid-cols-2 gap-4">
            {mapActions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.id}
                  onClick={() => handleQuickAction(action.id)}
                  className={`h-28 flex flex-col space-y-3 border-0 transition-all duration-200 hover:scale-105 ${action.color}`}
                >
                  <Icon className="h-7 w-7" />
                  <span className="text-sm font-medium">{action.label}</span>
                </Button>
              );
            })}
          </div>
        </div>

        {/* Recent Announcements */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-800">Recent Alerts</h2>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('announcements')} className="text-blue-600">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            <Card className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start space-x-4">
                <div className="p-2 bg-yellow-100 rounded-full">
                  <Megaphone className="h-5 w-5 text-yellow-600" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-800">Weather Alert</p>
                  <p className="text-sm text-gray-500">2 hours ago</p>
                </div>
              </div>
            </Card>
            <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start space-x-4">
                <div className="p-2 bg-blue-100 rounded-full">
                  <MapPin className="h-5 w-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-800">Building Maintenance</p>
                  <p className="text-sm text-gray-500">5 hours ago</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}