
  # Campus Safety App (Community)

  This is a code bundle for Campus Safety App (Community). The original project is available at https://www.figma.com/design/NrYCF8HfkJqoBrg8EccIFW/Campus-Safety-App--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  